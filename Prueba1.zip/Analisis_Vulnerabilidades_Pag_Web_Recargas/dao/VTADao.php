<?php

final class VTADao {

    /** @var mixed */
    private $db = null;

    public function __destruct() {
        // close db connection
        $this->db = null;
    }
	
	public function fetchAll($serviceNumber,$orderby,$order,$fchini,$fchfin,$limit,$offset) {
        $sql = 'SELECT *
				FROM (
				select 
				   t.externalId Referencia,
				   case t.rechargeType 
				   when \'2\' then \'RECARGA SALDO\'
				   when \'7\' then \'RECARGA TELEVISION\'
				   when \'22\' then \'RECARGA PREPAGO\'
				   when \'31\' then \'RECARGA APLICACIONES\'
				   when \'27\' then \'RECARGA INTERNET WIFI\'
				   when \'35\' then \'RECARGA TAXIMETRO\'
				   else \'RECARGAS OTRAS\' end Tipo_Recarga,
				   t.requestDate Fecha_Hora,
				   t.amount Valor,
				   case t.statusTransaction
				   when \'PENDING\' then \'PE\' 
				   when \'APPOVED\' then \'PS\'
				   when \'REVERSE\' then \'RV\'
				   when \'REJECT\' then \'RJ\'
				   when \'TAKEN\' then \'PC\'
				   else \'PN\' end Estado,
				   upper(b.nombre) Pago
				   from transaction_payment t, banco b
				   where t.bankId=b.banco_id
				   and t.serviceNumber = \''.$serviceNumber.'\'
				   and t.requestDate BETWEEN \''.$fchini.' 00:00:00 \' and \''.$fchfin. ' 23:59:59 \'
				union 
				select 
				   t.externalId Referencia,
				   case t.rechargeType 
				   when \'2\' then \'RECARGA SALDO\'
				   when \'7\' then \'RECARGA TELEVISION\'
				   when \'22\' then \'RECARGA PREPAGO\'
				   when \'31\' then \'RECARGA APLICACIONES\'
				   when \'27\' then \'RECARGA INTERNET WIFI\'
				   when \'35\' then \'RECARGA TAXIMETRO\'
				   else \'RECARGAS OTRAS\' end Tipo_Recarga,
				   t.requestDate Fecha_Hora,
				   t.amount Valor,
				   case t.statusTransaction
				   when \'PENDING\' then \'PE\' 
				   when \'APPOVED\' then \'PS\'
				   when \'REVERSE\' then \'RV\'
				   when \'REJECT\' then \'RJ\'
				   when \'TAKEN\' then \'PC\'
				   else \'PN\' end Estado,
				   upper(b.nombre) Pago
				   from transaction_paymentLog t, banco b
				   where t.bankId=b.banco_id 
				   and serviceNumber = \''.$serviceNumber.'\'
				   and t.requestDate BETWEEN \''.$fchini.' 00:00:00 \' and \''.$fchfin.' 23:59:59 \'
				   ) as re
				   ORDER BY '.$orderby.' '.$order.'
				   OFFSET '.$offset.' ROWS
					FETCH NEXT '.$limit.' ROWS ONLY'
				   ;
				   //echo $sql;
        try {
			$stid = $this->getDb()->prepare($sql);
			//$stid->bindValue(':serviceNumber', $serviceNumber , PDO::PARAM_STR);
			$stid->execute();
			return $stid->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $exc) {
            //error_log($exc->getMessage());
			echo $exc->getMessage();
        }
    }
	
	public function fetchAllTot($serviceNumber,$fchini,$fchfin) {
        $sql = 'SELECT count(*) as count
				FROM (
				select 
				   t.externalId Referencia,
				   case t.rechargeType 
				   when \'2\' then \'RECARGA SALDO\'
				   when \'7\' then \'RECARGA TELEVISION\'
				   when \'22\' then \'RECARGA PREPAGO\'
				   when \'31\' then \'RECARGA APLICACIONES\'
				   when \'27\' then \'RECARGA INTERNET WIFI\'
				   when \'35\' then \'RECARGA TAXIMETRO\'
				   else \'RECARGAS OTRAS\' end Tipo_Recarga,
				   t.requestDate Fecha_Hora,
				   t.amount Valor,
				   case t.statusTransaction
				   when \'PENDING\' then \'PE\' 
				   when \'APPOVED\' then \'PS\'
				   when \'REVERSE\' then \'RV\'
				   when \'REJECT\' then \'RJ\'
				   when \'TAKEN\' then \'PC\'
				   else \'PN\' end Estado,
				   upper(b.nombre) Pago
				   from transaction_payment t, banco b
				   where t.bankId=b.banco_id
				   and t.serviceNumber = \''.$serviceNumber.'\'
				   and t.requestDate BETWEEN \''.$fchini.' 00:00:00 \' and \''.$fchfin. ' 23:59:59 \'
				union 
				select 
				   t.externalId Referencia,
				   case t.rechargeType 
				   when \'2\' then \'RECARGA SALDO\'
				   when \'7\' then \'RECARGA TELEVISION\'
				   when \'22\' then \'RECARGA PREPAGO\'
				   when \'31\' then \'RECARGA APLICACIONES\'
				   when \'27\' then \'RECARGA INTERNET WIFI\'
				   when \'35\' then \'RECARGA TAXIMETRO\'
				   else \'RECARGAS OTRAS\' end Tipo_Recarga,
				   t.requestDate Fecha_Hora,
				   t.amount Valor,
				   case t.statusTransaction
				   when \'PENDING\' then \'PE\' 
				   when \'APPOVED\' then \'PS\'
				   when \'REVERSE\' then \'RV\'
				   when \'REJECT\' then \'RJ\'
				   when \'TAKEN\' then \'PC\'
				   else \'PN\' end Estado,
				   upper(b.nombre) Pago
				   from transaction_paymentLog t, banco b
				   where t.bankId=b.banco_id 
				   and serviceNumber = \''.$serviceNumber.'\'
				   and t.requestDate BETWEEN \''.$fchini.' 00:00:00 \' and \''.$fchfin.' 23:59:59 \'
				   ) as re'
				   ;
        try {
			$stid = $this->getDb()->prepare($sql);
			//$stid->bindValue(':serviceNumber', $serviceNumber , PDO::PARAM_STR);
			$stid->execute();
			return $stid->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $exc) {
            //error_log($exc->getMessage());
			echo $exc->getMessage();
        }
    }
	
	
	public function InsertTrnPay($data) {
        $sql = 'INSERT INTO transaction_payment(transactionId,externalId,ordererIdentification,ordererName,rechargeType,amount,rechargeDetail,branchId,pointSale,requestDate,limitDate,serviceNumber,statusAPP,statusTransaction,packageCode,groupId,attempts,bankId,meansId,deeplink) 
		VALUES (:transactionId,:externalId,:ordererIdentification,:ordererName,:rechargeType,:amount,:rechargeDetail,:branchId,:pointSale,:requestDate,:limitDate,:serviceNumber,:statusAPP,:statusTransaction,:packageCode,:groupId,:attempts,:bankId,:meansId,:deeplink)';
        try {
			$stid = $this->getDb()->prepare($sql);
			$stid->bindValue(':transactionId', $data['transactionId'] , PDO::PARAM_STR);
			$stid->bindValue(':externalId', $data['externalId'] , PDO::PARAM_STR);
			$stid->bindValue(':ordererIdentification', $data['ordererIdentification'] , PDO::PARAM_STR);
			$stid->bindValue(':ordererName', $data['ordererName'] , PDO::PARAM_STR);
			$stid->bindValue(':rechargeType', $data['rechargeType'] , PDO::PARAM_INT);
			$stid->bindValue(':amount', $data['amount'] , PDO::PARAM_INT);
			$stid->bindValue(':rechargeDetail', $data['rechargeDetail'] , PDO::PARAM_STR);
			$stid->bindValue(':branchId', $data['branchId'] , PDO::PARAM_STR);
			$stid->bindValue(':pointSale', $data['pointSale'] , PDO::PARAM_STR);
			$stid->bindValue(':requestDate', $data['requestDate'] , PDO::PARAM_STR);
			$stid->bindValue(':limitDate', $data['limitDate'] , PDO::PARAM_STR);
			$stid->bindValue(':serviceNumber', $data['serviceNumber'] , PDO::PARAM_STR);
			$stid->bindValue(':statusAPP', $data['statusAPP'] , PDO::PARAM_STR);
			$stid->bindValue(':statusTransaction', $data['statusTransaction'] , PDO::PARAM_STR);
			$stid->bindValue(':packageCode', $data['packageCode'] , PDO::PARAM_INT);
			$stid->bindValue(':groupId', $data['groupId'] , PDO::PARAM_INT);
			$stid->bindValue(':attempts', $data['attempts'] , PDO::PARAM_INT);
			$stid->bindValue(':bankId', $data['bankId'] , PDO::PARAM_INT);
			$stid->bindValue(':meansId', $data['meansId'] , PDO::PARAM_INT);
			$stid->bindValue(':deeplink', $data['deeplink'] , PDO::PARAM_STR);
			
			$sonuc = $stid->execute();
			$last_id = $sonuc;
			return $last_id;
        } catch (Exception $exc) {
            error_log($exc->getMessage());
			//echo $exc->getMessage();
        }
    }
	
	public function StatusTrn($data) {
        $sql = 'SELECT *
				FROM transaction_paymentLog  
				WHERE externalid = :externalId
				AND transactionId = :transactionId';
        try {
			$stid = $this->getDb()->prepare($sql);
			$stid->bindValue(':externalId', $data['externalId'] , PDO::PARAM_STR);
			$stid->bindValue(':transactionId', $data['transactionId'] , PDO::PARAM_STR);
			$stid->execute();
			return $stid->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $exc) {
            error_log($exc->getMessage());
			//echo $exc->getMessage();
        }
    }
	
	public function UpdateTrnRJ($data) {
        $sql = 'UPDATE transaction_payment
				SET statusTransaction = \'REJECTED\'
				WHERE externalId =  :clientTrnId ';
        try {
			$stid = $this->getDb()->prepare($sql);
			$stid->bindValue(':clientTrnId', $data['clientTrnId'] , PDO::PARAM_STR);
			
			$stid->execute();
			return $rowCount = $stid->rowCount();
        } catch (Exception $exc) {
            error_log($exc->getMessage());
			//echo $exc->getMessage();
        }
    }
	
	public function DeleteTrnPay($data) {
        $sql = 'DELETE FROM transaction_payment WHERE externalId = :clientTrnId ';
        try {
			$stid = $this->getDb()->prepare($sql);
			$stid->bindValue(':clientTrnId', $data['clientTrnId'] , PDO::PARAM_STR);
			
			$stid->execute();
			return $rowCount = $stid->rowCount();
        } catch (Exception $exc) {
            error_log($exc->getMessage());
			//echo $exc->getMessage();
        }
    }
	
	public function UpdateTrnPay($data) {
        $sql = 'UPDATE transaction_payment
				SET transactionId = :transactionId,
				transferNumber = :transferNumber,
				statusTransaction = :statusTransaction, 
				moneyType = :moneyType,
				paymentDate = getdate() 
				where externalId = :externalId';
        try {
			$stid = $this->getDb()->prepare($sql);
			$stid->bindValue(':transactionId', $data['transactionId'] , PDO::PARAM_STR);
			$stid->bindValue(':transferNumber', $data['transferNumber'] , PDO::PARAM_STR);
			$stid->bindValue(':statusTransaction', $data['statusTransaction'], PDO::PARAM_STR);
			$stid->bindValue(':moneyType', $data['moneyType'], PDO::PARAM_STR);
			$stid->bindValue(':externalId', $data['externalId'], PDO::PARAM_STR);
			$stid->execute();
            return $rowCount = $stid->rowCount();
        } catch (Exception $exc) {
            error_log($exc->getMessage());
			//echo $exc->getMessage();
        }
    }
	
	public function UpdateTrnPayRejected($data) {
        $sql = 'UPDATE transaction_payment
				SET transactionId = :transactionId,
				transferNumber = :transferNumber,
				statusTransaction = :statusTransaction, 
				moneyType = :moneyType 
				where externalId = :externalId';
        try {
			$stid = $this->getDb()->prepare($sql);
			$stid->bindValue(':transactionId', $data['transactionId'] , PDO::PARAM_STR);
			$stid->bindValue(':transferNumber', $data['transferNumber'] , PDO::PARAM_STR);
			$stid->bindValue(':statusTransaction', $data['statusTransaction'], PDO::PARAM_STR);
			$stid->bindValue(':moneyType', $data['moneyType'], PDO::PARAM_STR);
			$stid->bindValue(':externalId', $data['externalId'], PDO::PARAM_STR);
			$stid->execute();
            return $rowCount = $stid->rowCount();
        } catch (Exception $exc) {
            error_log($exc->getMessage());
			//echo $exc->getMessage();
        }
    }
	
	public function ValTrnPend($data) {
        $sql = ' SELECT COUNT(*)
				 FROM transaction_payment
				 WHERE externalId = :externalId 
				 AND statusTransaction = :statusTransaction';
        try {
			$stid = $this->getDb()->prepare($sql);
			$stid->bindValue(':externalId', $data['externalId'], PDO::PARAM_STR);
			$stid->bindValue(':statusTransaction', $data['statusTransaction'], PDO::PARAM_STR);
			$stid->execute();
            return $stid->fetchColumn();
        } catch (Exception $exc) {
            error_log($exc->getMessage());
			//echo $exc->getMessage();
        }
    }
	
	public function mediobanco($banco_id,$medio_name) {
        $sql = 'SELECT medio_banco_id FROM tlc_ta_medio_banco WHERE banco_id = :banco_id and medio_name = :medio_name';
        try {
			$stid = $this->getDb()->prepare($sql);
			$stid->bindValue(':banco_id', $banco_id, PDO::PARAM_INT);
			$stid->bindValue(':medio_name', $medio_name, PDO::PARAM_STR);
			$stid->execute();
            return $stid->fetchColumn();
        } catch (Exception $exc) {
            error_log($exc->getMessage());
			//echo $exc->getMessage();
        }
    }
	
	public function ValRecLog($data) {
        $sql = 'SELECT COUNT(*)
				FROM tlc_ta_transaccion t,transaction_paymentLog p
				WHERE t.external_id = p.externalId
				AND t.servicenumber = p.serviceNumber
				AND t.external_id = :externalId
				AND t.prepay_error = :prepay_error
				AND p.transactionId = :transactionId
				AND p.statusTransaction = :statusTransaction';
        try {
			$stid = $this->getDb()->prepare($sql);
			$stid->bindValue(':externalId', $data['externalId'], PDO::PARAM_STR);
			$stid->bindValue(':prepay_error', $data['prepay_error'], PDO::PARAM_STR);
			$stid->bindValue(':transactionId', $data['transactionId'], PDO::PARAM_STR);
			$stid->bindValue(':statusTransaction', $data['statusTransaction'], PDO::PARAM_STR);
			$stid->execute();
            return $stid->fetchColumn();
        } catch (Exception $exc) {
            //error_log($exc->getMessage());
			echo $exc->getMessage();
        }
    }
	
	protected function getDb() {
        if ($this->db !== null) {
            return $this->db;
        }
        //$config = Config::getConfig('dbVTA');
		$login = 'proc_credito';
		$passw = 'proc_credito';
		//echo $this->getDsn();
		//die();
        try {
			$this->db = new PDO($this->getDsn(), $login, $passw);
            $this->db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (PDOException $exc) {
            error_log($exc->getMessage());
			echo $exc->getMessage()."<br>";
			echo $exc->getCode()."<br>";
			
            //throw new Exception($exc->getMessage(), $exc->getCode(), $exc->getPrevious());
        }
        return $this->db;
    }

    private function getDsn() {
		$host   = '172.18.95.8';
		$dbname = 'CreditosBancoPrepago';
        return sprintf('sqlsrv:Server=%s,4436;Database=%s', $host, $dbname);
    }

    private static function throwDbError(array $errorInfo) {
        // TODO log error, send email, etc.
        throw new Exception('DB error [' . $errorInfo[0] . ', ' . $errorInfo[1] . ']: ' . $errorInfo[2]);
    }
}
