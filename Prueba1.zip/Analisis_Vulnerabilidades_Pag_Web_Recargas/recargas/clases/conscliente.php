<?php
//------------------------------------------------------------------------------------------------------------------------
//  PROYECTO: RECARGAS CON DE UNA
//  CLIENTE:  CNT EP
//  DESARROLLADO POR:  CNT EP
//  AUTOR:  Fabian Villavicencio Paez
//  EMAIL:  fabiane.villavicencio@cnt.gob.ec
//  WEBSITE:  http://www.cnt.gob.ec

//  TITULO:  conscliente.php
//  DESCRIPCION:  Permite consultar el valor a pagar
//  FECHA DE CREACION:  29-08-2024
//  --------------------------------------------------------------------------------------------------------
//  MODIFICACIONES:
//     FECHA            AUTOR           		DESCRIPCION

require_once('../../libs/conexion/connSmart.php');

class conscliente
{
  var $numserv;
  
  /*Constructor*/
	public function __construct($iProductType,$numserv,$iPackageCode)
	{
		$this->iProductType = $iProductType;
		$this->numserv      = $numserv;
		$this->iPackageCode = $iPackageCode;
	}
	
	function getDatos()
	{
		$this->clientecnt();
		
		$content = array('oErrorCode' => $this->oErrorCode,
						 'oErrorMsg' => $this->oErrorMsg,
						 'onombrecliente' => $this->onombrecliente,
						 'ocedula'   => $this->ocedula);
		return $content;
	}
  
	function clientecnt()
	{ 
		global $conexion;

		$conexion = connSmart();
		
		$funSql = "begin \n".
			  "proc_vta.tlc_pk_VentaTiempoAire.PR_VALIDA_NUMESERV_PRODUCT(:iProductType,:iServiceNumber,:iPackageCode,:oproducto,:ociclo,:ocontrato,:ofactivacion,:oplancomercialid,:oplancomercial,:oplataforma,:onombrecliente,:ocedula,:oErrorCode,:oErrorMsg,:ocodigobodegaid,:onumerosim,:onombrebodega);  \n".
			  "end;";
		//echo $funSql;
		$rsDataCliente = $conexion->PrepareSP($funSql,true);
		$conexion->Parameter($rsDataCliente,$this->iProductType,'iProductType',false);
		$conexion->Parameter($rsDataCliente,$this->numserv,'iServiceNumber',false);
		$conexion->Parameter($rsDataCliente,$this->iPackageCode,'iPackageCode',false);
		$conexion->Parameter($rsDataCliente,$this->oproducto,'oproducto',true);
		$conexion->Parameter($rsDataCliente,$this->ociclo,'ociclo',true);
		$conexion->Parameter($rsDataCliente,$this->ocontrato,'ocontrato',true);
		$conexion->Parameter($rsDataCliente,$this->ofactivacion,'ofactivacion',true);
		$conexion->Parameter($rsDataCliente,$this->oplancomercialid,'oplancomercialid',true);
		$conexion->Parameter($rsDataCliente,$this->oplancomercial,'oplancomercial',true);
		$conexion->Parameter($rsDataCliente,$this->oplataforma,'oplataforma',true);
		$conexion->Parameter($rsDataCliente,$this->onombrecliente,'onombrecliente',true);
		$conexion->Parameter($rsDataCliente,$this->ocedula,'ocedula',true);
		$conexion->Parameter($rsDataCliente,$this->oErrorCode,'oErrorCode',true);
		$conexion->Parameter($rsDataCliente,$this->oErrorMsg,'oErrorMsg',true);
		$conexion->Parameter($rsDataCliente,$this->ocodigobodegaid,'ocodigobodegaid',true);
		$conexion->Parameter($rsDataCliente,$this->onumerosim,'onumerosim',true);
		$conexion->Parameter($rsDataCliente,$this->onombrebodega,'onombrebodega',true);

		$this->DataCliente = $conexion->Execute($rsDataCliente);	
  }
	function paymentRequest($valor,$urldeuna,$secret,$key,$detail,$pointsale,$tiempoexp)
	{
		$curl = curl_init();
		curl_setopt_array($curl, array(
			CURLOPT_URL => $urldeuna,
			CURLOPT_RETURNTRANSFER => true,
			CURLOPT_ENCODING => '',
			CURLOPT_MAXREDIRS => 10,
			CURLOPT_TIMEOUT => 0,
			CURLOPT_FOLLOWLOCATION => true,
			CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
			CURLOPT_CUSTOMREQUEST => 'POST',
			CURLOPT_POSTFIELDS =>'{
				"pointOfSale": "'.$pointsale.'",
				"qrType": "dynamic",
				"amount": '.$valor.',
				"detail": "'.$detail.' '.$valor.'",
				"internalTransactionReference": "CNT270824002",
				"format": "2",
				"expiredTime": '.$tiempoexp.'
			}',
			CURLOPT_HTTPHEADER => array(
				'x-api-secret:'.$secret,
				'x-api-key:'.$key,
				'Content-Type: application/json',
				'User-Agent:' . $_SERVER['HTTP_USER_AGENT'],
			),
		));
		$response = curl_exec($curl);
		curl_close($curl);
		$resDeuna = json_decode($response,true);
		return $resDeuna;
	}
	function isMobileDevice()
	{
		$aMobileUA = array(
			'/iphone/i' => 'iPhone', 
			'/ipod/i' => 'iPod', 
			'/ipad/i' => 'iPad', 
			'/android/i' => 'Android', 
			'/blackberry/i' => 'BlackBerry', 
			'/webos/i' => 'Mobile'
		);

		//Return true if Mobile User Agent is detected
		foreach($aMobileUA as $sMobileKey => $sMobileOS){
			if(preg_match($sMobileKey, $_SERVER['HTTP_USER_AGENT'])){
				return 'MOVIL';
			}
		}
		//Otherwise return false..  
		return 'WEB';
	}
}
?>