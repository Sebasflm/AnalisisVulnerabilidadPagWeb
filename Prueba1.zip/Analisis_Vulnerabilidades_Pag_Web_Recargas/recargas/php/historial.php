<!doctype html>
    <html lang="en">
    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0 shrink-to-fit=no">
        <meta name="mobile-web-app-capable" content="yes">

        <!-- Bootstrap CSS -->
        <link rel="stylesheet" type="text/css" href="../../libs/bootstrap-5.3.3/css/bootstrap.min.css">
		
		<link rel="stylesheet" type="text/css" href="../css/recargas.css">
		<link rel="stylesheet" type="text/css" href="../css/historial.css">
		<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/datetime/1.5.1/css/dataTables.dateTime.min.css">
		<link href="../../libs/easyui/themes/metro/easyui.css" rel="stylesheet" type="text/css">
		<link rel="stylesheet" type="text/css" href="../../libs/datatables/1.13.7/css/jquery.dataTables.min.css"/>
		<link rel="stylesheet" type="text/css" href="../../libs/datatables/buttons/2.4.2/css/buttons.dataTables.min.css">
		<script type="text/javascript" src="../../libs/jquery/jquery-3.7.1.min.js"></script>
		
		<script type="text/javascript" src="../../libs/datatables/1.13.7/js/jquery.dataTables.min.js"></script>	
		<script type="text/javascript" src="../../libs/datatables/buttons/1.3.1/js/dataTables.buttons.min.js"></script> 
		<script type="text/javascript" language="javascript" src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.29.2/moment.min.js"></script>
		<script type="text/javascript" language="javascript" src="https://cdn.datatables.net/datetime/1.5.1/js/dataTables.dateTime.min.js"></script>
		<script type="text/javascript" src="../../libs/datatables/buttons/1.3.1/js/buttons.html5.min.js"></script>
		<script>
			$(document).ready(function(){
				let minIniDate, maxIniDate;
				var table = $('#historial').DataTable({
					dom: 'Bfiprtip',
					"scrollX": true,
					"ajax": {
						"url": 'loadhist.php',
						data: function (d) {
							d.fchini  = $('#minIni').val();
							d.fchfin  = $('#maxIni').val();
							var numserv = $('#numserv').val();
							const numserv0 = numserv.slice(1)
							d.numserv = numserv0;
						},
						"type": 'POST'
					},
					"columns": [
						{ 'data': 'Referencia'},
						{ 'data': 'Tipo_Recarga'},
						{ 'data': 'Fecha_Hora' },
						{ 'data': 'Valor' },
						{ 'data': 'Estado' },
						{ 'data': 'Pago' }
					],
					"processing": true,
					"search": {
						return: true
					},
					"serverSide": true,
					"order": [[2, 'asc']],
					"pageLength": 10,
					"language": {
						'url': '../../libs/datatables/js/i18n/Spanish.json'
					},
					"searching": false,
					"buttons": [],					
				});
				
				minDateIni = $('#minIni').dtDateTime({
				format: 'YYYY-MM-DD'
				});
				maxDateIni = $('#maxIni').dtDateTime({
					format: 'YYYY-MM-DD'
				});				
				// Refilter the table
				document.querySelectorAll('#minIni, #maxIni, #numserv').forEach((el) => {
					el.addEventListener('change', () => table.draw());
				});
			});
		</script>
        <title>¡Recargate con CNT!</title>
    </head>
    <body>
	<div>
        <?php 
			include('navbar.php'); 
		?>
		<div id="titrec" class="container">
			<div class="row h-auto">
				<div class="col-2"></div>
				<div class="col-8 t1"><p id="txttit" class='p1'></p></div>
				<div class="col-2"></div>
			</div>
		</div>
		<div class="container table-responsive">
			<table border="1" align="left" width="50%">
				<tbody>
					<tr>
						<td align="right">Número de Servicio:</td>
						<td><input type="text" maxlength="10" class="resizedTextbox txtnumcons" id="numserv" name="numserv" style="font-size: 12px"></td>
					</tr>
					<tr>
						<td colspan="2" width='auto' height='10px'>&nbsp</td>
					</tr>
					<tr>
						<td align="right" height='10px'>Fecha Inicial:</td>
						<td><input type="text" class="resizedTextbox txtnumcons" id="minIni" name="minIni" style="font-size: 12px"></td>
					</tr>
					<tr>
						<td colspan="2"  width='auto' height='10px'>&nbsp</td>
					</tr>
					<tr>
						<td align="right">Fecha Final:</td>
						<td><input type="text" class="resizedTextbox txtnumcons" id="maxIni" name="maxIni" style="font-size: 12px"></td>
					</tr>
				</tbody>
			</table>
		</div>
		<div class="container table-responsive">
			<table class="table border display nowrap table-hover" id="historial" name="historial" style="width:100%" border="1">
				<thead class="table-success">
					<tr>
						<th scope="col">Referencia</th>
						<th scope="col">Tipo Recarga</th>
						<th scope="col">Fecha Hora</th>
						<th scope="col">Valor</th>
						<th scope="col">Estado</th>
						<th scope="col">Pago</th>
					</tr>
				</thead>		
			<table>
		</div>
		<p>
        <div class='row'>
            <div class="col-3"></div>
            <div class='col-6 text-center tg pg'>Glosario de Estado de Pagos</div>
            <div class="col-3"></div>
        </div>
        </p>
        <p>
        <div class='row'>
            <div class="col-2 text-end tg pg">PS</div>
            <div class='col-4 text-left t5 p5'>Pago Exitoso</div>
            <div class="col-2 text-end tg pg">PN</div>
            <div class="col-4 text-left t5 p5">Pago no realizado</div>
        </div>
        <div class='row'>
            <div class="col-2 text-end tg pg">PE</div>
            <div class='col-4 text-left t5 p5'>Pendiente</div>
            <div class="col-2 text-end tg pg">RJ</div>
            <div class="col-4 text-left t5 p5">Rechazado</div>
        </div>
        <div class='row'>
            <div class="col-2 text-end tg pg">RV</div>
            <div class='col-4 text-left t5 p5'>Pago Reversado</div>
            <div class="col-2 text-end tg pg"></div>
            <div class="col-4 text-left t5 p5"></div>
        </div>
        </p>
    </div>
	
    <script src="../../libs/easyui/jquery.easyui.min.js"></script>
    <script type="text/javascript" src="../../libs/easyui/locale/easyui-lang-es.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js"></script>
	<script src="../../libs/bootstrap-5.3.3/js/bootstrap.min.js"></script>
	
	<script type="text/javascript" src="../js/historial.js"></script>
  </body>
</html>