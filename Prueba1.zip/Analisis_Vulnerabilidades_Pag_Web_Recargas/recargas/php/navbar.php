<nav class="navbar navbar-expand-lg navbar-light bg-primary" data-bs-theme="dark">
	<div class="container" style="display: flex; flex-wrap: wrap; align-items: center; justify-content: space-between;">
		<button class="navbar-toggler border-0 mt-2 order-1 nav-collapse-btn collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#navbarTogglerDemo01" 
				aria-controls="nav-collapse" aria-expanded="false" aria-label="Toggle navigation" variant="link" style="overflow-anchor: none;">
			<span class="navbar-toggler-icon"></span>
		</button>
		<a class="navbar-brand order-2 m-0 ml-2" href="index.php">
			<img name="logocnt" class="img-fluid" width="88px" src="../images/logo_cnt_blanco.png" border="0" id="logo_cnt" alt="CNT" />
		</a>
		<!--<div class="navbar-nav order-3 order-md-4 pr-3 pr-md-0">
			<svg viewBox="0 0 576 512" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="cart-shopping" role="img" class="svg-inline--fa fa-cart-shopping">
				<path fill="currentColor" d="M96 0C107.5 0 117.4 8.19 119.6 19.51L121.1 32H541.8C562.1 32 578.3 52.25 572.6 72.66L518.6 264.7C514.7 278.5 502.1 288 487.8 288H170.7L179.9 336H488C501.3 336 512 346.7 512 360C512 373.3 501.3 384 488 384H159.1C148.5 384 138.6 375.8 136.4 364.5L76.14 48H24C10.75 48 0 37.25 0 24C0 10.75 10.75 0 24 0H96zM128 464C128 437.5 149.5 416 176 416C202.5 416 224 437.5 224 464C224 490.5 202.5 512 176 512C149.5 512 128 490.5 128 464zM512 464C512 490.5 490.5 512 464 512C437.5 512 416 490.5 416 464C416 437.5 437.5 416 464 416C490.5 416 512 437.5 512 464z" class="">
				</path>
			</svg>
		</div>-->				
		<div class="order-4 order-md-3 pt-2 pt-md-0 px-3 px-md-4 collapse navbar-collapse" id="navbarTogglerDemo01">
			<ul class="navbar-nav" style="margin-left: auto!important;">
				<li class="nav-item dropdown-title nav-link">
					<a href="index.php" class="navmenu" role="button" aria-expanded="false">
						<span class="navmenu">Inicio</span>
					</a>
				</li>
				<li class="nav-item dropdown m-0">
					<a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
						<span class="navmenu">Móvil</span>
					</a>
				
					<ul class="dropdown-menu">
						<li>
							<a role="menuitem" href="https://cnt.com.ec/productos/planes-movil-pospago" target="_self" class="dropdown-item">
								<span>Móvil Pospago</span>
							</a>
						</li>
						<li>
							<a role="menuitem" href="https://cnt.com.ec/productos/planes-movil-prepago" target="_self" class="dropdown-item">
								<span>Móvil Prepago</span>
							</a>
						</li>
						<li>
							<a role="menuitem" href="https://cnt.com.ec/recargas" target="_self" class="dropdown-item">
								<span>Cómo realizar tus recargas CNT</span>
							</a>
						</li>
						<li>
							<a role="menuitem" href="https://cnt.com.ec/equipos" target="_self" class="dropdown-item">
								<span>Equipos</span>
							</a>
						</li>
					</ul>
				</li>
				<li class="nav-item dropdown m-0">
					<a href="#" class="nav-link dropdown-toggle" role="button" data-bs-toggle="dropdown" aria-expanded="false">
						<span class="navmenu">Internet</span>
					</a>
					<ul tabindex="-1" class="dropdown-menu m-0 dropdown-menu-border rounded-0">
						<li>
							<a role="menuitem" href="https://cnt.com.ec/productos/planes-internet" target="_self" class="dropdown-item">
								<span>Internet</span>
							</a>
						</li>
						<li>
							<a role="menuitem" href="https://gis.cnt.gob.ec/appgeoportal/" rel="noopener" target="_blank" class="dropdown-item">
								<span>Cobertura CNT</span>
							</a>
						</li>
						<li>
							<a role="menuitem" href="https://cnt.com.ec/navegoseguro" target="_self" class="dropdown-item">
								<span class="yellow">Navego seguro</span>
							</a>
						</li>
						<li>
							<a role="menuitem" href="https://www.cnt.com.ec/comunicaciones/calculatusmegas" target="_self" class="dropdown-item">
								<span class="yellow">Calcula tu velocidad</span>
							</a>
						</li>
						<li>
							<a role="menuitem" href="https://cnt.com.ec/comunicaciones/cambiate-a-fibra-optica" target="_self" class="dropdown-item">
								<span class="yellow">¿Quieres migrar a Fibra Óptica?</span>
							</a>
						</li>
						<li>
							<a role="menuitem" href="https://www.cnt.com.ec/buen-uso-internet/" target="_self" class="dropdown-item">
								<span class="yellow">Buen uso de Internet</span>
							</a>
						</li>
					</ul>
				</li>
				<li class="nav-item nav-link dropdown-title">
					<a href="https://www.cnt.com.ec/productos/planes-television" class="navmenu">
					<span>Televisión</span>
					</a>
				</li>
				<li class="nav-item dropdown m-0">
					<a href="index.php" class="nav-link dropdown-toggle" role="button" data-bs-toggle="dropdown" aria-expanded="false">
						<span class="navmenu">Telefonía</span>
					</a>
					<ul tabindex="-1" class="dropdown-menu m-0 dropdown-menu-border rounded-0">
						<li>
							<a role="menuitem" href="https://cnt.com.ec/productos/planes-telefonia-fija" target="_self" class="dropdown-item">
								<span>Telefonía Fija</span>
							</a>
						</li>
						<li>
							<a role="menuitem" href="https://cnt.com.ec/promociones/la-edad-perfecta-para-compartir-mas" target="_self" class="dropdown-item">
								<span>Adulto Mayor</span>
							</a>
						</li>
						<li>
							<a role="menuitem" href="https://micnt.com.ec/cntapp/guia104/php/guia_cntat.php?hflagsubmit=0&amp;cmbcriterio=1" target="_self" class="dropdown-item">
								<span>Guía Telefónica</span>
							</a>
						</li>
						<li>
							<a role="menuitem" href="https://www.cnt.com.ec/buen-uso-internet" target="_self" class="dropdown-item">
								<span>Buen uso de Internet</span>
							</a>
						</li>
					</ul>
				</li>
				<li class="nav-item dropdown m-0">
					<a href="index.php" class="nav-link dropdown-toggle" role="button" data-bs-toggle="dropdown" aria-expanded="false">
						<span class="navmenu">Necesito ayuda</span>
					</a>
					<ul tabindex="-1" class="dropdown-menu m-0 dropdown-menu-border rounded-0">
						<li>
							<a role="menuitem" href="https://cnt.com.ec/consultacoactiva" target="_self" class="dropdown-item">
								<span>Consulta Coactiva</span>
							</a>
						</li> 
						<li>
							<a role="menuitem" href="https://teayuda.cnt.com.ec" target="_self" class="dropdown-item">
								<span>CNT te ayuda</span>
							</a>
						</li>
						<li>
							<a role="menuitem" href="https://www.cnt.com.ec/acuerdos" target="_self" class="dropdown-item">
								<span class="yellow">Acuerdos de pagos LOAH</span>
							</a>
						</li>
						<li>
							<a role="menuitem" href="https://cnt.com.ec/seguridad-en-redes-y-servicios" target="_self" class="dropdown-item">
								<span>Seguridad y Redes</span>
							</a>
						</li>
						<li>
							<a role="menuitem" href="https://pbxvirtual.fastboy.com.ec/portal/login.action" rel="noopener" target="_blank" class="dropdown-item">
								<span>PBX Virtual</span>
							</a>
						</li>
						<li>
							<a role="menuitem" href="https://www.speedtest.net/" rel="noopener" target="_blank" class="dropdown-item">
								<span class="yellow">Medidor de Velocidad</span>
							</a>
						</li>
						<li>
							<a role="menuitem" href="https://cnt.com.ec/servicios-en-linea" rel="noopener" target="_blank" class="dropdown-item">
								<span class="yellow">Servicios en línea</span>
							</a>
						</li>
						<li>
							<a role="menuitem" href="https://www.ecu911.gob.ec/lineas-suspendidas/" target="_self" class="dropdown-item">
								<span>Números suspendidos</span>
							</a>
						</li>
						<li>
							<a role="menuitem" href="http://micnt.com.ec/cntapp/efacturacion/instructivo/" target="_self" class="dropdown-item">
								<span>Factura Electrónica</span>
							</a>
						</li>
						<li>
							<a role="menuitem" href="https://pagarmisfacturas.cnt.gob.ec/cntpagos/php/index.php" target="_self" class="dropdown-item">
								<span class="yellow">Pagar mis facturas</span>
							</a>
						</li>
						<li>
							<a role="menuitem" href="https://flujodecolas.cnt.gob.ec/web/" rel="noopener" target="_blank" class="dropdown-item">
								<span class="yellow">Agendar una cita</span>
							</a>
						</li>
						<li>
							<a role="menuitem" href="https://www.cnt.com.ec/preguntas-frecuentes" rel="noopener" target="_blank" class="dropdown-item">
								<span class="yellow">Preguntas Frecuentes</span>
							</a>
						</li>
					</ul>
				</liv>
				<li class="nav-item nav-link dropdown-title">
					<a href="https://www.cnt.com.ec/promociones" class="navmenu" href="#">
						<span>Promociones</span>
					</a>
				</li>
				<li class="nav-item nav-link dropdown-title">
					<a href="https://www.cnt.com.ec/cntplay" class="navmenu" href="#">
						<span>CNT Play</span>
					</a>
				</li>
			</ul>
		</div>
	</div>
</nav>