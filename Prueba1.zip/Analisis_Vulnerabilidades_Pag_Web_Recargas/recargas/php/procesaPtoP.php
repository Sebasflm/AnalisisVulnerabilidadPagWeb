<?php
error_reporting(E_ALL);
ini_set('display_errors', '1');
require_once('../clases/conscliente.php');
require_once('../servicios/sbopa_param.php');
require_once('../servicios/sbopa_prd.php');
require_once('../../dao/VTADao.php');

$vtaDao = new VTADao();

$numserv = filter_input(INPUT_POST, 'numserv', FILTER_SANITIZE_NUMBER_INT);
$valrec  = filter_input(INPUT_POST, 'recval', FILTER_SANITIZE_NUMBER_INT);
$btnid   = filter_input(INPUT_POST, 'btnid', FILTER_SANITIZE_SPECIAL_CHARS);

$rsPrd     = fnSConsultarBOPA_PRD($btnid,1);
$producttype = $rsPrd->fields[0];
$nametype    = $rsPrd->fields[1];
$packagecode = $rsPrd->fields[2];
$valrec      = $rsPrd->fields[4];
$branchid    = $rsPrd->fields[11];
$pointsale   = $rsPrd->fields[12];
$storeid     = $rsPrd->fields[14];
$login       = $rsPrd->fields[15];
$secretKey   = $rsPrd->fields[16];

$objConscliente = new conscliente($producttype,$numserv,$packagecode);
$dataFact = $objConscliente->getDatos();
$device   = $objConscliente->isMobileDevice();

$oErrorCode     = $dataFact['oErrorCode'];
$oErrorMsg      = $dataFact['oErrorMsg'];
$onombrecliente = $dataFact['onombrecliente'];
$ocedula        = $dataFact['ocedula'];

if($oErrorCode == 0)
{
	$date1 = new DateTime("now", new DateTimeZone('America/Guayaquil') );
	$date2 = new DateTime("now", new DateTimeZone('America/Guayaquil') );
	
	$rsParam   = fnSConsultarBOPA_PARAM('PARAM_ID = 6',1);
	$bankid      = $rsParam->fields[1];
	//$login       = $rsParam->fields[5];
    //$secretKey   = $rsParam->fields[6];
	$groupmax    = $rsParam->fields[8];
	$description = $rsParam->fields[9];
	$urldeuna    = $rsParam->fields[16];
	$tiempoexp   = $rsParam->fields[20];
	$iva         = $rsParam->fields[21];
	
	$detail = $description." ".$nametype." ".number_format($valrec,2,'.');
	$seed        = $date1->format('c');
	
	if (function_exists('random_bytes')) 
	{
        $rawNonce = bin2hex(random_bytes(16));
    } 
	else (function_exists('openssl_random_pseudo_bytes')) 
	{
        $rawNonce = bin2hex(openssl_random_pseudo_bytes(16));
    }
	
	$groupid = mt_rand(1, $groupmax);
	
	$nonce     = base64_encode($rawNonce);
	$tranKey   = base64_encode(hash('sha256', $rawNonce.$seed.$secretKey, true));
    $reference = $date1->format('dmyHis').str_pad($groupid, 2, "0", STR_PAD_LEFT);
    $userAgent = $_SERVER['HTTP_USER_AGENT'];
    $ref       = base64_encode($reference);
    $url       = $rsParam->fields[10].$ref;
	
	$valiva  = number_format(($iva * $valrec) / (100 + $iva),2);
	$baseiva = number_format($valrec,2) - $valiva;
	
	$rsMedioBanco = $vtaDao->mediobanco($bankid,$device);
	
	$curl = curl_init();

    curl_setopt_array($curl, array(
        CURLOPT_URL => $urldeuna."session",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "POST",
        CURLOPT_HTTPHEADER => array(
            "Content-Type: application/json",
        ),
    ));
	
	$minexp = $tiempoexp / 60;
	$date2->modify("+".$minexp." minute");
	
	$request = [
        "auth" => [
            "login" => $login,
            "seed" => $seed,
            "nonce" => $nonce,
            "tranKey" => $tranKey
        ],
        "locale" => 'es_EC',
        "payment" => [
            "reference" => $reference, 
            "description" => $detail,
            "amount" => [
                "currency" => "USD",
                "total"    => $valrec,
                "taxes" => [
							   [
									"kind"   => "valueAddedTax",
									"amount" => $valiva,
									"base"   => $baseiva
							   ]
				],
            ],
            "allowPartial" => false,
        ],
        "expiration" => $date2->format('c'),
        "returnUrl" => $url,
        "ipAddress" => '201.219.1.71',
        "userAgent" => $userAgent,
    ];
	
	$data = json_encode($request);
	
	//echo $data;

    curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
    $response = curl_exec($curl);
    $err = curl_error($curl);
    curl_close($curl);

    if ($err) 
    {
        echo $err;
    } 
    else 
    {
		$desc_error = '';
		$resPtoP = json_decode($response,true);
		
		//print_r($resPtoP);
		
		if ($resPtoP['status']['status']=='OK')
        {
			$data = [
					'transactionId'  	    => $resPtoP['requestId'],
					'externalId'     	    => $reference,
					'ordererIdentification' => $ocedula,
					'ordererName'			=> $onombrecliente,
					'rechargeType'   		=> $producttype,
					'amount'         		=> $valrec,
					'rechargeDetail' 		=> $detail,
					'branchId' 	        	=> $storeid,
					'pointSale' 	 		=> $storeid,
					'requestDate'    		=> $date1->format('Y-m-d H:i:s'),
					'limitDate'      		=> $date2->format('Y-m-d H:i:s'),
					'serviceNumber'  		=> $numserv,
					'statusAPP'      		=> 'SUCCESS',
					'statusTransaction' 	=> 'PENDING',
					'packageCode'    		=> $packagecode,
					'groupId'        		=> $groupid,
					'attempts'       		=> 0,
					'bankId'         		=> $bankid,
					'meansId'        		=> $rsMedioBanco,
					'deeplink'       		=> $resPtoP['processUrl'],
			];
		
            $rsInsTrans = $vtaDao->InsertTrnPay($data);
            if ($rsInsTrans != 1)
			{
            	$resPtoP = [];
			}
        }
	}
}
else
{
	$resPtoP = [];
}

$content = array('cliente' => $oErrorCode, 'msgcli' => $oErrorMsg,'device' => $device);
$resultado = array_merge($resPtoP, $content);

$json = json_encode($resultado);
echo $json;