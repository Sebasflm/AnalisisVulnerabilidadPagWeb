<?php
header('Access-Control-Allow-Methods: GET');
header('Accept-Charset: utf-8');
header('X-XSS-Protection: 1; mode=block');
header('X-Content-Type-Options: nosniff');

function ReturnIndex()
{
	$host  = filter_var($_SERVER['HTTP_HOST'],FILTER_SANITIZE_FULL_SPECIAL_CHARS);
	$uri   = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
	$extra = filter_var('index.php',FILTER_SANITIZE_FULL_SPECIAL_CHARS);
	return "http://$host$uri/$extra";
}

if ($_SERVER['REQUEST_METHOD'] <> 'GET') {
    header(sprintf('%s 405', $_SERVER['SERVER_PROTOCOL']));
    exit('Method Not Allowed');
}

$parametros = ['id', 'clientTransactionId'];

foreach ($parametros as $param) {
    if (!filter_has_var(INPUT_GET, $param)) {
        header(sprintf('%s 400', $_SERVER['SERVER_PROTOCOL']));
        //exit('Bad Request');
		$urlindex = ReturnIndex();
		header("Location: $urlindex");
    }
}

if($_REQUEST['id'] == '' || $_REQUEST['clientTransactionId'] == '')
{
	$urlindex = ReturnIndex();
	header("Location: $urlindex");
}

?>
<!DOCTYPE html>
<html>
    <head>
        <script>
            function submitForm() {
                //document.getElementById("myForm").submit();
            }
        </script>
    </head>
    <body onload="submitForm()">
        <form id="myForm" name="myForm" action="transaccion.php" method="post">
            <?= sprintf('<input type="hidden" name="id" value="%s">', filter_input(INPUT_GET, 'id', FILTER_SANITIZE_NUMBER_INT)); ?>
            <?= sprintf('<input type="hidden" name="clientTransactionId" value="%s">', filter_input(INPUT_GET, 'clientTransactionId', FILTER_SANITIZE_NUMBER_INT)); ?>
        </form>
    </body>
</html>