<?php
error_reporting(E_ALL);
ini_set('display_errors', '1');
require_once('../clases/conscliente.php');
require_once('../servicios/sbopa_param.php');
require_once('../servicios/sbopa_prd.php');
require_once('../../dao/VTADao.php');

$vtaDao = new VTADao();

$clientTrnId = filter_input(INPUT_POST, 'clientTrnId', FILTER_SANITIZE_NUMBER_INT);

$data = [
		'clientTrnId' => $clientTrnId,
];

$rsuPDTrans = $vtaDao->UpdateTrnRJ($data);

if($rsuPDTrans == 1)
{
	
	$rsDelTrans = $vtaDao->DeleteTrnPay($data);

	if ($rsDelTrans != 1)
	{
		$resPP = [];
	}	
	else
	{
		$resPP = array('clientTrnId' => $clientTrnId, 'delTrans' => $rsDelTrans);
	}
}
else
{
	$resPP = [];
}

$resultado = array_merge($resPP);

$json = json_encode($resultado);
echo $json;