<!doctype html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
		<title>¡Recargate con CNT!</title>
		<link rel="stylesheet" type="text/css" href="../../libs/bootstrap-5.3.3/css/bootstrap.min.css">
		<link rel="stylesheet" type="text/css" href="../css/recargas.css">
		<script src="https://checkout.placetopay.com/lightbox.min.js"></script>
		<script type='module' src='https://cdn.payphonetodoesposible.com/box/v1.1/payphone-payment-box.js'></script>
		<link rel='stylesheet' href="https://cdn.payphonetodoesposible.com/box/v1.1/payphone-payment-box.css">
	</head>
	<body>
	<div>
		<?php 
			include('navbar.php');
			//$txtrecar = '¡RECÁRGATE CON CNT!';
			//$txtelige = 'Elige la categoría de recarga';
			//$txtvalor = 'Elige el valor de tu recarga prepago';
		?>
		<div id="titrec" class="container">
			<div class="row h-auto">
				<div class="col-2"></div>
				<div class="col-8 t1"><p id="txttit" class='p1'></p></div>
				<div class="col-2"></div>
			</div>
		</div>
		<div id="msgrec" class="container">
			<div class="row h-auto">
				<div class="col-2"></div>
				<div class="col-8 t2"><p id="txtsec" class='p2'></p></div>
				<div class="col-2"></div>
			</div>
		</div>
		<div id="catrec" class="container">
			<div class="row">
				<div class="col-sm-2"></div>
				<div class="col-sm-2 col-md-2 col-lg-2 text-center">
					<input type="image" class="img-fluid btnimg" src="../images/btnmenu001g.png" border="0" onclick="recSaldo()" id="btnmenu001g" alt="btnmenu001g"/>
				</div>
				<div class="col-sm-2 col-md-2 col-lg-2 text-center">
					<input type="image" class="img-fluid btnimg" src="../images/btnmenu002g.png" border="0" onclick="recPrepago()" id="btnmenu002g" alt="btnmenu002g"/>
				</div>
				<div class="col-sm-2 col-md-2 col-lg-2 text-center">
					<input type="image" class="img-fluid btnimg" src="../images/btnmenu003g.png" border="0" onclick="recAplica()" id="btnmenu003g" alt="btnmenu003g"/>
				</div>
				<div class="col-sm-2 col-md-2 col-lg-2 text-center">
					<input type="image" class="img-fluid btnimg" src="../images/btnmenu004g.png" border="0" onclick="recPlus()" id="btnmenu004g" alt="btnmenu004g"/>
				</div>
				<div class="col-sm-2 col-md-2 col-lg-2"></div>
			</div>
			<div class="row" style="height: 20px;">
				<div class="col-4"></div>
				<div class="col-4 h-50"><input type="hidden" id='amountrec' name='amountrec' value="0"></div>
				<div class="col-4"></div>
			</div>
			<div class="row">
				<div class="col-sm-3"></div>
				<div class="col-sm-6 text-center">
					<div id="carouselSlider" class="carousel slide" data-bs-touch="false">
						<div class="carousel-inner">
							<div class="carousel-item active">
								<img name="slice01" class="img-fluid d-block w-100" src="../images/slice01.png" border="0" id="slice01" alt="Recarga Saldo" />
							</div>
							<div class="carousel-item">
								<img name="slice02" class="img-fluid d-block w-100" src="../images/slice02.png" border="0" id="slice02" alt="Recarga Paquetes Movil" />
							</div>
							<div class="carousel-item">
								<img name="slice03" class="img-fluid d-block w-100" src="../images/slice03.png" border="0" id="slice03" alt="Recarga Paquetes Movil de Aplicaciones" />
							</div>
							<div class="carousel-item">
								<img name="slice04" class="img-fluid d-block w-100" src="../images/slice04.png" border="0" id="slice04" alt="Recarga Paquetes Plus" />
							</div>
						</div>
						<button class="carousel-control-prev" type="button" data-bs-target="#carouselSlider" data-bs-slide="prev">
							<span class="carousel-control-prev-icon" aria-hidden="true"></span>
							<span class="visually-hidden">Previous</span>
						</button>
						<button class="carousel-control-next" type="button" data-bs-target="#carouselSlider" data-bs-slide="next">
							<span class="carousel-control-next-icon" aria-hidden="true"></span>
							<span class="visually-hidden">Next</span>
						</button>
					</div>
				</div>
				<div class="col-sm-3"></div>
			</div>
			<br><br>
		</div>
		<div id="valrec" class="container hidden">
		<form id="frmrec" method='POST'>
			<div class="row">
				<div class="col-sm-2"></div>
				<div class="col-sm-4">
					<div class="row">	
						<div class="col-sm-1"></div>
						<div class="col-sm-10 d-block">
							<div class="btn-toolbar justify-content-md-center" role="toolbar" aria-label="Toolbar with button groups">
								<div class="btn-group btn-group-lg" role="group" aria-label="First group">
									<div class="row row-cols-3">
										<div class="col-sm-4">
											<label for="btnsaldo3">
												<input type="radio" class="btn-check" name="btnsaldo" id="btnsaldo3" value="3" autocomplete="off" onclick="getbtnval(this.value,this.id)">
												<img class="img-fluid" src="../images/btnsaldo3g.png" id="btnsaldo3g" name="btnsaldo3g" alt="$3">
											</label>
										</div>
										<div class="col-sm-4">
											<label for="btnsaldo5">
												<input type="radio" class="btn-check" name="btnsaldo" id="btnsaldo5" value="5" autocomplete="off" onclick="getbtnval(this.value,this.id)">
												<img class="img-fluid" src="../images/btnsaldo5g.png" id="btnsaldo5g" name="btnsaldo5g" alt="$5">
											</label>
										</div>
										<div class="col-sm-4">
											<label for="btnsaldo6">
												<input type="radio" class="btn-check" name="btnsaldo" id="btnsaldo6" value="6" autocomplete="off" onclick="getbtnval(this.value,this.id)">
												<img class="img-fluid" src="../images/btnsaldo6g.png" id="btnsaldo6g" name="btnsaldo6g" alt="$6">
											</label>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div class="col-sm-1"></div>	
					</div>
					<div class="row">	
						<div class="col-sm-1"></div>
						<div class="col-sm-10 text-center">
							<div class="btn-toolbar justify-content-md-center" role="toolbar" aria-label="Toolbar with button groups">
								<div class="btn-group btn-group-lg" role="group" aria-label="First group">
									<div class="row row-cols-3">
										<div class="col-sm-4">
											<label for="btnsaldo10">
												<input type="radio" class="btn-check" name="btnsaldo" id="btnsaldo10" value="10" autocomplete="off" onclick="getbtnval(this.value,this.id)">
												<img class="img-fluid" src="../images/btnsaldo10g.png" id="btnsaldo10g" name="btnsaldo10g" alt="$10">
											</label>
										</div>
										<div class="col-sm-4">
											<label for="btnsaldo15">
												<input type="radio" class="btn-check" name="btnsaldo" id="btnsaldo15" value="15" autocomplete="off" onclick="getbtnval(this.value,this.id)">
												<img class="img-fluid" src="../images/btnsaldo15g.png" id="btnsaldo15g" name="btnsaldo15g" alt="$15">
											</label>
										</div>
										<div class="col-sm-4">	
											<label for="btnsaldo20">
												<input type="radio" class="btn-check" name="btnsaldo" id="btnsaldo20" value="20" autocomplete="off" onclick="getbtnval(this.value,this.id)">
												<img class="img-fluid" src="../images/btnsaldo20g.png" id="btnsaldo20g" name="btnsaldo20g" alt="$20">
											</label>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div class="col-sm-1"></div>	
					</div>
				</div>
				<div class="col-sm-4">
					<div class="row" style="height: 70px;">
						<div class="col-2"></div>
						<div class="col-8 text-center"><img class="img-fluid" width="277px" height="60px" src="../images/btncontinuarg.png" id="btncontinuarg" name="btncontinuarg" alt="Continuar"></div>
						<div class="col-2"></div>
					</div>
					<div class="row">
						<div class="col-2"></div>
						<div class="col-8 text-center">
							<input maxlength="10" class="resizedTextbox txtnumcons" type="text" id='numserv' name='numserv' placeholder="Número celular" required>
							<input type="hidden" id='recarga' name='recarga' value="0">
							<input type="hidden" id='btnid' name='btnid' value="0">
						</div>
						<div class="col-2"></div>
					</div>
					<div class="row" style="height: 20px;">
						<!--<div class="col-1"></div>-->
						<div class="col-12 pe text-center"><p><span id="msgvalserv"></span></p></div>
						<!--<div class="col-1"></div>-->
					</div>
					<div class="row" style="height: auto;">
						<div class="col-1"></div>
						<div class="col-10 pl">Elige el método de pago de tu preferencia, enseguida serás direccionado a una plataforma segura de pagos.</div>
						<div class="col-1"></div>
					</div>
					<div class="row">
						<div class="col-2"></div>
						<div class="col-8 text-center">&nbsp;</div>
						<div class="col-2"></div>
					</div>
					<div class="row" style="height: auto;">
						<div class="col-1">&nbsp;</div>    
						<div class="col-10 pl">
							<input type="checkbox" class="form-check-input" id="chkAceptoRec" onClick="fnContinuarRec();">
							<span>He leído y acepto los </span> <a href="../docs/Terminos_y_Condiciones_Boton_de_Pagos_CNT_EP.pdf" target="_blank">T&eacute;rminos y condiciones&nbsp;</a>
							<span>y la </span> <a href="../docs/CNT_Politicas_Proteccion_Datos.pdf" target="_blank">Pol&iacute;tica de aceptaci&oacute;n de datos</a>
						</div>
						<div class="col-1"></div>
					</div>
					<div class="row">
						<div class="col-2"></div>
						<div class="col-8 text-center">&nbsp;</div>
						<div class="col-2"></div>
					</div>
					<div class="row">
						<!--<div class="col-4 text-center"><input type="image" class="img-fluid imagebtn" height="40px" src="../images/btn_deuna.png" border="0" onclick="fnPagoDeUna(1);return false;" id="btndeunarec" alt="DE UNA" disabled/></div>-->
						<div class="col-2"></div>
						<div class="col-4 text-center"><input type="image" class="img-fluid imagebtn" height="40px" src="../images/btnpayphone.png" border="0" onclick="fnPagoPP(1);return false;" id="btnpprec" alt="PAYPHONE" disabled/></div>
						<div class="col-4 text-center"><input type="image" class="img-fluid imagebtn" height="40px" src="../images/btnplacetopay.png" border="0" onclick="fnPagoPtoP(1);return false;" id="btnptoprec" alt="PLACETOPAY" disabled/></div>
						<div class="col-2"></div>
					</div>
				</div>
				<div class="col-sm-2"></div>
			</div>
		</form>
		</div>
		<div id="reclista" class="container hidden">
			<div class="row h-auto">
				<div class="col-4"></div>
				<div class="col-4 text-center"><img id="deunaqr" width="100%" alt="QR DEUNA"/></div>
				<div class="col-4"></div> 
			</div>
		</div>
		<div id="msgreclista" class="container hidden">
			<div class="row h-auto">
				<div class="col-2"></div>
				<div class="col-8 t2"><p id="txtrec" class='p2'></p></div>
				<div class="col-2"></div>
			</div>
		</div>
		<div id="valpre" class="container hidden">
		<form id="frmpre" method='POST'>
			<div class="row">
				<div class="col-sm-3"></div>
				<div class="col-sm-4">
					<div class="row">
						<div class="col-sm-12">
							<div class="btn-toolbar justify-content-md-center" role="toolbar" aria-label="Toolbar with button groups">
								<div class="btn-group btn-group-lg" role="group" aria-label="First group">
									<div class="row row-cols-4">
										<div class="col-sm-3">
											<label for="btnprepago1">
												<input type="radio" class="btn-check" name="btnprepago" id="btnprepago1" value="1" autocomplete="off" onclick="getbtnvalp(this.value,this.id)">
												<img class="img-fluid" src="../images/btnprepago1g.png" id="btnprepago1g" name="btnprepago1g" alt="$1">
											</label>
										</div>
									
										<div class="col-sm-3">
											<label for="btnprepago2">
												<input type="radio" class="btn-check" name="btnprepago" id="btnprepago2" value="2" autocomplete="off" onclick="getbtnvalp(this.value,this.id)">
												<img class="img-fluid" src="../images/btnprepago2g.png" id="btnprepago2g" name="btnprepago2g" alt="$2">
											</label>
										</div>
									
										<div class="col-sm-3">
											<label for="btnprepago3">
												<input type="radio" class="btn-check" name="btnprepago" id="btnprepago3" value="3" autocomplete="off" onclick="getbtnvalp(this.value,this.id)">
												<img class="img-fluid" src="../images/btnprepago3g.png" id="btnprepago3g" name="btnprepago3g" alt="$3">
											</label>
										</div>
									
										<div class="col-sm-3">
											<label for="btnprepago5">
												<input type="radio" class="btn-check" name="btnprepago" id="btnprepago5" value="5" autocomplete="off" onclick="getbtnvalp(this.value,this.id)">
												<img class="img-fluid" src="../images/btnprepago5g.png" id="btnprepago5g" name="btnprepago5g" alt="$5">
											</label>
										</div>
									</div>
								</div>
							</div>
						</div>	
					</div>
					<div class="row">
						<div class="col-sm-12">
							<div class="btn-toolbar justify-content-md-center" role="toolbar" aria-label="Toolbar with button groups">
								<div class="btn-group btn-group-lg" role="group" aria-label="First group">
									<div class="row row-cols-4">
										<div class="col-sm-3">
											<label for="btnprepago6">
												<input type="radio" class="btn-check" name="btnprepago" id="btnprepago6" value="6" autocomplete="off" onclick="getbtnvalp(this.value,this.id)">
												<img class="img-fluid" src="../images/btnprepago6g.png" id="btnprepago6g" name="btnprepago6g" alt="$6">
											</label>
										</div>
										<div class="col-sm-3">
											<label for="btnprepago10">
												<input type="radio" class="btn-check" name="btnprepago" id="btnprepago10" value="10" autocomplete="off" onclick="getbtnvalp(this.value,this.id)">
												<img class="img-fluid" src="../images/btnprepago10g.png" id="btnprepago10g" name="btnprepago10g" alt="$10">
											</label>
										</div>
										<div class="col-sm-3">
											<label for="btnprepago15">
												<input type="radio" class="btn-check" name="btnprepago" id="btnprepago15" value="15" autocomplete="off" onclick="getbtnvalp(this.value,this.id)">
												<img class="img-fluid" src="../images/btnprepago15g.png" id="btnprepago15g" name="btnprepago15g" alt="$15">
											</label>
										</div>
										<div class="col-sm-3">
											<label for="btnprepago20">
												<input type="radio" class="btn-check" name="btnprepago" id="btnprepago20" value="20" autocomplete="off" onclick="getbtnvalp(this.value,this.id)">
												<img class="img-fluid" src="../images/btnprepago20g.png" id="btnprepago20g" name="btnprepago20g" alt="$20">
											</label>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-sm-12">
							<div class="justify-content-md-center" role="toolbar" aria-label="Toolbar with button groups">
								<div class="btn-group-lg" role="group" aria-label="First group">
									<div class="row">
										<div class="col-sm-2"></div>
										<div class="col-sm-8"style="height: 150px;">
											<label for="btnprepagoi3" style="display: inline !important;">
												<input type="radio" class="btn-check" name="btnprepago" id="btnprepagoi3" value="3" autocomplete="off" onclick="getbtnvalp(this.value,this.id)">
												<img class="btnprei3" src="../images/btnprepagoi3g.png" id="btnprepagoi3g" name="btnprepagoi3g" alt="Paquete Prepago Ilimitado $3">
											</label>
										</div>
										<div class="col-sm-2"></div>
									</div>
								</div>
							</div>
						</div>					
					</div>
				</div>
				<div class="col-sm-3 text-center" style="height: auto;">
					<img class="imgpaq" src="../images/paquete1.png" id="paqueteprepago" name="paqueteprepago" alt="Paquete Prepago">
				</div>
				<div class="col-sm-2"></div>
			</div>
			<div class="row">
				<div class="col-sm-3"></div>	
				<div class="col-sm-7">
					<div class="row" style="height: 70px;">
						<div class="col-2"></div>
						<div class="col-8 text-center">
							<img class="img-fluid" width="277px" height="60px" src="../images/btncontinuarg.png" id="btncontinuarpg" name="btncontinuarpg" alt="Continuar">
						</div>
						<div class="col-2"></div>
					</div>
					<div class="row">
						<div class="col-2"></div>
						<div class="col-8 text-center">
							<input maxlength="10" class="resizedTextbox" type="text" id='numservp' name='numservp' class="txtnumcons" placeholder="Número celular" required>
							<input type="hidden" id='recargap' name='recargap' value="0">
							<input type="hidden" id='btnidp' name='btnidp' value="0">
						</div>
						<div class="col-2"></div>
					</div>
					<div class="row" style="height: 20px;">
						<div class="col-1"></div>
						<div class="col-10 pe text-center"><p><span id="msgvalservp"></span></p></div>
						<div class="col-1"></div>
					</div>
					<div class="row" style="height: auto;">
						<div class="col-2"></div>
						<div class="col-8 pl">Elige el método de pago de tu preferencia, enseguida serás direccionado a una plataforma segura de pagos.</div>
						<div class="col-2"></div>
					</div>
					<div class="row">
						<div class="col-2"></div>
						<div class="col-8 text-center">&nbsp;</div>
						<div class="col-2"></div>
					</div>
					<div class="row" style="height: auto;">
						<div class="col-2">&nbsp;</div>    
						<div class="col-8 pl">
							<input type="checkbox" class="form-check-input" id="chkAceptoPre" onClick="fnContinuarPre();">
							<span>He leído y acepto los </span> <a href="../docs/Terminos_y_Condiciones_Boton_de_Pagos_CNT_EP.pdf" target="_blank">T&eacute;rminos y condiciones&nbsp;</a>
							<span>y la </span> <a href="../docs/CNT_Politicas_Proteccion_Datos.pdf" target="_blank">Pol&iacute;tica de aceptaci&oacute;n de datos</a>
						</div>
						<div class="col-2"></div>
					</div>
					<div class="row">
						<div class="col-2"></div>
						<div class="col-8 text-center">&nbsp;</div>
						<div class="col-2"></div>
					</div>
					<div class="row">
						<div class="col-sm-2"></div>
						<div class="col-sm-8 text-center">
							<div class="row row-cols-3">
								<!--<div class="col-sm-4 text-center"><input type="image" class="img-fluid imagebtn" height="40px" src="../images/btn_deuna.png" border="0" onclick="fnPagoDeUna(2);return false;" id="btndeunapre" alt="DE UNA" disabled/></div>-->
								<div class="col-2"></div>
								<div class="col-sm-4 text-center"><input type="image" class="img-fluid imagebtn" height="40px" src="../images/btnpayphone.png" border="0" onclick="fnPagoPP(2);return false;" id="btnpppre" alt="PAYPHONE" disabled/></div>
								<div class="col-sm-4 text-center"><input type="image" class="img-fluid imagebtn" height="40px" src="../images/btnplacetopay.png" border="0" onclick="fnPagoPtoP(2);return false;" id="btnptoppre" alt="PLACETOPAY" disabled/></div>
								<div class="col-2"></div>
							</div>
						</div>
						<div class="col-sm-2"></div>
					</div>
				</div>
				<div class="col-sm-2"></div>
			</div>
		</form>
		</div>
		<div id="valapl" class="container hidden">
		<form id="frmapl">
			<div class="row">
				<div class="col-sm-3"></div>
				<div class="col-sm-3">
					<div class="row">
						<div class="col-sm-12">
							<div class="justify-content-md-center" role="toolbar" aria-label="Toolbar with button groups">
								<div class="btn-group-lg" role="group" aria-label="First group">
									<div class="row row-cols-4 p-1">
										<div class="col-sm-2"></div>
										<div class="col-sm-4">
											<label for="paq_netflix">
												<input type="radio" class="btn-check" name="btnaplicaciones" id="paq_netflix" value="1" autocomplete="off" onclick="getbtnvala(this.value,this.id)">
												<img class="img-fluid" src="../images/logo_netflix.png" id="logo_netflix" name="logo_netflix" alt="NETFLIX">
											</label>
										</div>
									
										<div class="col-sm-4">
											<label for="paq_instagram">
												<input type="radio" class="btn-check" name="btnaplicaciones" id="paq_instagram" value="1" autocomplete="off" onclick="getbtnvala(this.value,this.id)">
												<img class="img-fluid" src="../images/logo_instagram.png" id="logo_instagram" name="logo_instagram" alt="INSTAGRAM">
											</label>
										</div>
										<div class="col-sm-2"></div>
									</div>
								</div>
							</div>
						</div>	
					</div>
					<div class="row">
						<div class="col-sm-12">
							<div class="justify-content-md-center" role="toolbar" aria-label="Toolbar with button groups">
								<div class="btn-group-lg" role="group" aria-label="First group">
									<div class="row row-cols-4 p-1">
										<div class="col-sm-2"></div>
										<div class="col-sm-4">
											<label for="paq_spotify">
												<input type="radio" class="btn-check" name="btnaplicaciones" id="paq_spotify" value="1" autocomplete="off" onclick="getbtnvala(this.value,this.id)">
												<img class="img-fluid" src="../images/logo_spotify.png" id="logo_spotify" name="logo_spotify" alt="SPOTIFY">
											</label>
										</div>
										<div class="col-sm-4">
											<label for="paq_tiktok">
												<input type="radio" class="btn-check" name="btnaplicaciones" id="paq_tiktok" value="1" autocomplete="off" onclick="getbtnvala(this.value,this.id)">
												<img class="img-fluid" src="../images/logo_tiktok.png" id="logo_tiktok" name="logo_tiktok" alt="TIKTOK">
											</label>
										</div>
										<div class="col-sm-2"></div>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="row h-auto">
						<div class="col-sm-12">
							<div class="justify-content-md-center" role="toolbar" aria-label="Toolbar with button groups">
								<div class="btn-group-lg" role="group" aria-label="First group">
									<div class="row row-cols-4 p-1 align-items-center">
										<div class="col-sm-2"></div>
										<div class="col-sm-4">
											<label for="paq_waze">
												<input type="radio" class="btn-check" name="btnaplicaciones" id="paq_waze" value="1" autocomplete="off" onclick="getbtnvala(this.value,this.id)">
												<img class="img-fluid" src="../images/logo_waze.png" id="logo_waze" name="logo_waze" alt="WAZE">
											</label>
										</div>
									
										<div class="col-sm-4">
											<label for="paq_google">
												<input type="radio" class="btn-check" name="btnaplicaciones" id="paq_google" value="1" autocomplete="off" onclick="getbtnvala(this.value,this.id)">
												<img class="img-fluid" src="../images/logo_google.png" id="logo_google" name="logo_google" alt="GOOGLE">
											</label>
										</div>
										<div class="col-sm-2"></div>
									</div>
								</div>
							</div>
						</div>					
					</div>
				</div>
				<div class="col-sm-3 text-center">
					<img class="imgapp" src="../images/appnetflix.png" id="paqueteaplicacion" name="paqueteaplicacion" alt="Paquete de Aplicación">
				</div>
				<div class="col-sm-3"></div>
			</div>
			<div class="row">
				<div class="col-sm-2"></div>	
				<div class="col-sm-8">
					<div class="row" style="height: 70px;">
						<div class="col-2"></div>
						<div class="col-8 text-center">
							<img class="img-fluid" width="277px" height="60px" src="../images/btncontinuarg.png" id="btncontinuarag" name="btncontinuarag" alt="Continuar">
						</div>
						<div class="col-2"></div>
					</div>
					<div class="row">
						<div class="col-2"></div>
						<div class="col-8 text-center">
							<input maxlength="10" class="resizedTextbox" type="text" id='numserva' name='numserva' class="txtnumcons" placeholder="Número celular" required>
							<input type="hidden" id='recargaa' name='recargaa' value="0">
							<input type="hidden" id='btnida' name='btnida' value="0">
						</div>
						<div class="col-2"></div>
					</div>
					<div class="row" style="height: 20px;">
						<div class="col-1"></div>
						<div class="col-10 pe text-center"><p><span id="msgvalserva"></span></p></div>
						<div class="col-1"></div>
					</div>
					<div class="row" style="height: auto;">
						<div class="col-2"></div>
						<div class="col-8 pl">Elige el método de pago de tu preferencia, enseguida serás direccionado a una plataforma segura de pagos.</div>
						<div class="col-8"></div>
					</div>		
					<div class="row">
						<div class="col-2"></div>
						<div class="col-8 text-center">&nbsp;</div>
						<div class="col-2"></div>
					</div>
					<div class="row" style="height: auto;">
						<div class="col-2">&nbsp;</div>    
						<div class="col-8 pl">
							<input type="checkbox" class="form-check-input" id="chkAceptoApl" onClick="fnContinuarApl();">
							<span>He leído y acepto los </span> <a href="../docs/Terminos_y_Condiciones_Boton_de_Pagos_CNT_EP.pdf" target="_blank">T&eacute;rminos y condiciones&nbsp;</a>
							<span>y la </span> <a href="../docs/CNT_Politicas_Proteccion_Datos.pdf" target="_blank">Pol&iacute;tica de aceptaci&oacute;n de datos</a>
						</div>
						<div class="col-2"></div>
					</div>
					<div class="row">
						<div class="col-2"></div>
						<div class="col-8 text-center">&nbsp;</div>
						<div class="col-2"></div>
					</div>
					<div class="row">
						<div class="col-sm-2"></div>
						<div class="col-sm-8 text-center">
							<div class="row row-cols-3">
								<!--<div class="col-sm-4 text-center"><input type="image" class="img-fluid imagebtn" height="40px" src="../images/btn_deuna.png" border="0" onclick="fnPagoDeUna(3);return false;" id="btndeunaapl" alt="DE UNA" disabled/></div>-->
								<div class="col-2"></div>
								<div class="col-sm-4 text-center"><input type="image" class="img-fluid imagebtn" height="40px" src="../images/btnpayphone.png" border="0" onclick="fnPagoPP(3);return false;" id="btnppapl" alt="PAYPHONE" disabled/></div>
								<div class="col-sm-4 text-center"><input type="image" class="img-fluid imagebtn" height="40px" src="../images/btnplacetopay.png" border="0" onclick="fnPagoPtoP(3);return false;" id="btnptopapl" alt="PLACETOPAY" disabled/></div>
								<div class="col-2"></div>
							</div>
						</div>
						<div class="col-sm-2"></div>
					</div>
					
				</div>
				<div class="col-sm-2"></div>
			</div>
		</form>
		</div>
		<div id="valplus" class="container hidden">
		<form id="frmplus">
			<div class="row align-items-center" style="height: auto">
				<div class="col-sm-1" style="height: auto;"></div>
				<div class="col-sm-4 text-center" style="height: auto;">		
					<div class="row" style="height: auto; position: static">
						<div class="col-sm-12">
							<div role="toolbar" aria-label="Toolbar with button groups">
								<div class="btn-group btn-group-lg" role="group" aria-label="First group">
									<div class="row">
										<div class="col-sm-1"></div>
										<div class="col-sm-10">
											<label for="paqueteplus10">
												<input type="radio" class="btn-check" name="paqueteplus" id="paqueteplus10" value="10" autocomplete="off" onclick="getbtnvalpl(this.value,this.id)">
												<img class="btnplus" src="../images/paqueteplus10g.png" id="paqueteplus10g" name="paqueteplus10g" alt="$10">
											</label>
										</div>
										<div class="col-sm-1"></div>
									</div>
								</div>
							</div>
						</div>					
					</div>

					<div class="row" style="height: auto; position: static">
						<div class="col-sm-12">
							<div role="toolbar" aria-label="Toolbar with button groups">
								<div class="btn-group btn-group-lg" role="group" aria-label="First group">
									<div class="row">
										<div class="col-sm-1"></div>
										<div class="col-sm-10">
											<label for="paqueteplus20">
												<input type="radio" class="btn-check" name="paqueteplus" id="paqueteplus20" value="20" autocomplete="off" onclick="getbtnvalpl(this.value,this.id)">
												<img class="btnplus" src="../images/paqueteplus20g.png" id="paqueteplus20g" name="paqueteplus20g" alt="$20">
											</label>
										</div>
										<div class="col-sm-1"></div>
									</div>
								</div>
							</div>
						</div>					
					</div>
				</div>
				<div class="col-sm-2 text-center">
					<img class="imgplus" src="../images/paqplus10.png" id="paqueteplus" name="paqueteplus" alt="Paquete de Aplicación">
				</div>
				<div class="col-sm-4">
					<div class="row align-items-center" style="height: 65px;">
						<div class="col-2"></div>
						<div class="col-8 text-center">
							<img class="img-fluid" width="277px" height="60px" src="../images/btncontinuarplg.png" id="btncontinuarplg" name="btncontinuarplg" alt="Continuar">
						</div>
						<div class="col-2"></div>
					</div>
					<div class="row align-items-center" style="height: 30px;">
						<div class="col-2"></div>
						<div class="col-8 text-center">
							<input maxlength="10" class="resizedTextboxpl" type="text" id='numservpl' name='numservpl' class="txtnumcons" placeholder="Número celular" required>
							<input type="hidden" id='recargapl' name='recargapl' value="0">
							<input type="hidden" id='btnidpl' name='btnidpl' value="0">
						</div>
						<div class="col-2"></div>
					</div>
					<div class="row" style="height: 35px;">
						<div class="col-1"></div>
						<div class="col-10 pe text-center"><p><span id="msgvalservpl"></span></p></div>
						<div class="col-1"></div>
					</div>
					<div class="row" style="height: auto;">
						<div class="col-1"></div>
						<div class="col-10 pl">Elige el método de pago de tu preferencia, enseguida serás direccionado a una plataforma segura de pagos.</div>
						<div class="col-1"></div>
					</div>
					<div class="row">
						<div class="col-2"></div>
						<div class="col-8 text-center">&nbsp;</div>
						<div class="col-2"></div>
					</div>
					<div class="row" style="height: auto;">
						<div class="col-1">&nbsp;</div>    
						<div class="col-10 pl">
							<input type="checkbox" class="form-check-input" id="chkAceptoPlus" onClick="fnContinuarPlus();">
							<span>He leído y acepto los </span> <a href="../docs/Terminos_y_Condiciones_Boton_de_Pagos_CNT_EP.pdf" target="_blank">T&eacute;rminos y condiciones&nbsp;</a>
							<span>y la </span> <a href="../docs/CNT_Politicas_Proteccion_Datos.pdf" target="_blank">Pol&iacute;tica de aceptaci&oacute;n de datos</a>
						</div>
						<div class="col-1"></div>
					</div>
					<div class="row">
						<div class="col-2"></div>
						<div class="col-8 text-center">&nbsp;</div>
						<div class="col-2"></div>
					</div>
					<div class="row">
						<!--<div class="col-4 text-center"><input type="image" class="img-fluid imagebtn" height="45px" src="../images/btn_deuna.png" border="0" onclick="fnPagoDeUna(4);return false;" id="btndeunaplus" alt="DE UNA" disabled/></div>-->
						<div class="col-2"></div>
						<div class="col-4 text-center"><input type="image" class="img-fluid imagebtn" height="45px" src="../images/btnpayphone.png" border="0" onclick="fnPagoPP(4);return false;" id="btnppplus" alt="PAYPHONE" disabled/></div>
						<div class="col-4 text-center"><input type="image" class="img-fluid imagebtn" height="45px" src="../images/btnplacetopay.png" border="0" onclick="fnPagoPtoP(4);return false;" id="btnptopplus" alt="PLACETOPAY" disabled/></div>
						<div class="col-2"></div>
					</div>
				</div>
				<div class="col-sm-1"></div>
			</div>
		</form>
		</div>
		<div id="divregresar" class="container hidden">
			<div class="row" style="height: 100px;">
				<div class="col-2"></div>
				<div class="col-8 t2 p2">
					<br>
					<a href="index.php"><img width="100px" src="../images/btnregresar.png" id="btnregresar" name="btnregresar" alt="INICIO"></a>
					<br>
				</div>
				<div class="col-2"></div>
			</div>
		</div>
		<div class="modal fade" id="modalPP" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="modalPPLabel" aria-hidden="true">
		  <div class="modal-dialog">
			<div class="modal-content">
			  <div class="modal-header">
				<input type="hidden" id='clientTrnId' name='clientTrnId' value="0">
				<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
			  </div>
			  <div id="pp-button"></div>
			</div>
		  </div>
		</div>
		<footer id="footer" class="pb-3">
			<div class="container text-white">
				<div class="d-flex flex-column flex-lg-row justify-content-lg-center footer-link aling-items-start mt-3">
					<div class="mx-2 text-gray">
						<a href="index.php" title="Recargas" target="_self">Inicio</a>
					</div>
					<div class="mx-2 text-gray">
						<a href="https://pagarmisfacturas.cnt.gob.ec/cntpagos/docs/Preguntas_Frecuentes.pdf" title="Preguntas Frecuentes" target="_blank">FAQ Place to Pay</a>
					</div>
					<div class="mx-2 text-gray">
						<a href="historial.php	" target="_self" title="Historial de Recargas">Historial</a>
					</div>
					<div class="mx-2 text-gray">
						<a href="https://micnt.com.ec/" title="Mi CNT" target="_blank">Mi CNT</a>
					</div>
					<!--<div class="mx-2 text-gray">
						<a href="https://cnt.com.ec/repositorio-legal" title="Repositorio Legal" target="_blank">Repositorio Legal</a>
					</div>-->
				</div>
				<div class="copyright">
					<small>© Copyright 
						<strong>Corporación Nacional de Telecomunicaciones</strong>.<br>Todos derechos reservados. 2024
					</small>
				</div>
			</div>
			<section class="cookieControl cookie-control-cnt p-4"><!----> <!----> <!----></section>
		</footer>
		<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js"></script>
		<script src="../../libs/bootstrap-5.3.3/js/bootstrap.min.js"></script>
		<script type="text/javascript" src="../../libs/jquery/jquery-3.7.1.min.js"></script>
		<script type="text/javascript" src="../js/recargas.js"></script>
		<script src="../js/jquery.redirect.js"></script>
	</div>
	</body>
	<script>
		<!-- Suscribe el evento close -->
		/*P.on('close', function () {
			window.location.href = "index.php";
		});*/

		<!-- Suscribe el evento response -->
		P.on('response', function (response) {
			var amount = document.getElementById("amountrec").value;
			$.redirect('retorno.php', {'reference': response.reference, 'requestId': response.requestId, 'amount': amount, 'signature': response.signature, 'date': response.status.date, 'message': response.status.message, 'reason': response.status.reason, 'status': response.status.status});
		});
	</script>
</html>