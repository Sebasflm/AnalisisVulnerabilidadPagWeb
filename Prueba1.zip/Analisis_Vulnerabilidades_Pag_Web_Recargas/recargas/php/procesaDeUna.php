<?php
error_reporting(E_ALL);
ini_set('display_errors', '1');
require_once('../clases/conscliente.php');
require_once('../servicios/sbopa_param.php');
require_once('../servicios/sbopa_prd.php');
require_once('../../dao/VTADao.php');

$vtaDao = new VTADao();

$numserv = filter_input(INPUT_POST, 'numserv', FILTER_SANITIZE_NUMBER_INT);
$valrec  = filter_input(INPUT_POST, 'recval', FILTER_SANITIZE_NUMBER_INT);
$btnid   = filter_input(INPUT_POST, 'btnid', FILTER_SANITIZE_SPECIAL_CHARS);

$rsPrd     = fnSConsultarBOPA_PRD($btnid,1);
$producttype = $rsPrd->fields[0];
$nametype    = $rsPrd->fields[1];
$packagecode = $rsPrd->fields[2];
$valrec      = $rsPrd->fields[4];
$branchid    = $rsPrd->fields[11];
$pointsale   = $rsPrd->fields[12];

$objConscliente = new conscliente($producttype,$numserv,$packagecode);
$dataFact = $objConscliente->getDatos();
$device   = $objConscliente->isMobileDevice();

$oErrorCode = $dataFact['oErrorCode'];
$oErrorMsg  = $dataFact['oErrorMsg'];
$onombrecliente = $dataFact['onombrecliente'];
$ocedula        = $dataFact['ocedula'];

if($oErrorCode == 0)
{
	
	$rsParam   = fnSConsultarBOPA_PARAM('PARAM_ID = 5',1);
	$bankid    = $rsParam->fields[1];
	$key       = $rsParam->fields[5];
	$secret    = $rsParam->fields[6];
	$groupmax  = $rsParam->fields[8];
	$detail    = $rsParam->fields[9];
	$urldeuna  = $rsParam->fields[16];
	$tiempoexp = $rsParam->fields[20];
	
	$detail = $detail." ".$nametype." ".number_format($valrec,2,'.');
	$resDeuna = $objConscliente->paymentRequest($valrec,$urldeuna,$secret,$key,$detail,$pointsale,$tiempoexp);
	
	$date1 = new DateTime("now", new DateTimeZone('America/Guayaquil') );
	$date2 = new DateTime("now", new DateTimeZone('America/Guayaquil') );
	
	$minexp = $tiempoexp / 60;
	$date2->modify("+".$minexp." minute");
	
	$groupid = mt_rand(1, $groupmax);
	$externalId = $date1->format('dmyHis').str_pad($groupid, 2, "0", STR_PAD_LEFT);
	
	$rsMedioBanco = $vtaDao->mediobanco($bankid,$device);

	if($resDeuna['status'] == 1)
	{
		$data = [
				'transactionId'  	    => $resDeuna['transactionId'],
				'externalId'     	    => $externalId,
				'ordererIdentification' => $ocedula,
				'ordererName'			=> $onombrecliente,
				'rechargeType'   	    => $producttype,
				'amount'         	    => $valrec,
				'rechargeDetail' 	    => $detail,
				'branchId' 	        	=> $branchid,
				'pointSale' 	 		=> $pointsale,
				'requestDate'    		=> $date1->format('Y-m-d H:i:s'),
				'limitDate'      		=> $date2->format('Y-m-d H:i:s'),
				'serviceNumber'  		=> $numserv,
				'statusAPP'      		=> 'SUCCESS',
				'statusTransaction' 	=> 'PENDING',
				'packageCode'    		=> $packagecode,
				'groupId'        		=> $groupid,
				'attempts'       		=> 0,
				'bankId'         		=> $bankid,
				'meansId'        		=> $rsMedioBanco,
				'deeplink'       		=> $resDeuna['deeplink'],
		];
		
		$ins_trans_vta = $vtaDao->InsertTrnPay($data);
		if($ins_trans_vta != 1)
		{
			$resDeuna = [];
		}
	}
}
else
{
	$resDeuna = [];
}

$content = array('cliente' => $oErrorCode, 'msgcli' => $oErrorMsg,'device' => $device);
$resultado = array_merge($resDeuna, $content);

$json = json_encode($resultado);
echo $json;